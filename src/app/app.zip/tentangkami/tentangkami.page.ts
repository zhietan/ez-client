import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute,NavigationExtras } from '@angular/router';


@Component({
  selector: 'app-tentangkami',
  templateUrl: './tentangkami.page.html',
  styleUrls: ['./tentangkami.page.scss'],
})
export class TentangkamiPage implements OnInit {

  constructor(
    private router: Router,

  ) { }

  ngOnInit() {
  }

  back() {
    this.router.navigate(['/indexmenu']);
  }

}
