import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute,NavigationExtras } from '@angular/router';


@Component({
  selector: 'app-syaratketentuan',
  templateUrl: './syaratketentuan.page.html',
  styleUrls: ['./syaratketentuan.page.scss'],
})
export class SyaratketentuanPage implements OnInit {

  constructor(
    private router: Router,

  ) { }

  ngOnInit() {
  }

  back() {
    this.router.navigate(['/indexmenu']);
  }

}
