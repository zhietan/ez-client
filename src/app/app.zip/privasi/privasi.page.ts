import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute,NavigationExtras } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-privasi',
  templateUrl: './privasi.page.html',
  styleUrls: ['./privasi.page.scss'],
})
export class PrivasiPage implements OnInit {

  constructor(
    private router: Router,

  ) { }

  ngOnInit() {
  }

  back() {
    this.router.navigate(['/indexmenu']);
  }

}
